-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2020 at 04:14 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pms`
--

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `u_id` varchar(15) NOT NULL,
  `password` varchar(32) NOT NULL,
  `admin_name` varchar(30) NOT NULL,
  `college_name` varchar(30) NOT NULL,
  `website` varchar(50) DEFAULT NULL,
  `phone_no` varchar(15) NOT NULL,
  `location` varchar(30) NOT NULL,
  `landmark` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `post` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `approval_status` varchar(1) NOT NULL DEFAULT 'P' COMMENT 'P for panding,N for not approved,Y for apprroved',
  `m_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`u_id`, `password`, `admin_name`, `college_name`, `website`, `phone_no`, `location`, `landmark`, `city`, `post`, `email`, `approval_status`, `m_id`) VALUES
('ab12', 'c4ca4238a0b923820dcc509a6f75849b', 'qw', 'BVM', 'ews', '1213', 'sdsdf', 'xdfxfd', 'vxvcvc', 'qq', 'qq@g.c', 'P', 'M01'),
('ab123', 'c4ca4238a0b923820dcc509a6f75849b', 'qw', 'BVM', NULL, '1213', 'sdsdf', 'xdfxfd', 'vxvcvc', 'qq', 'qq@g1.c', 'P', 'M01'),
('C01', '81dc9bdb52d04dc20036dbd8313ed055', 'pqr', 'BBIT', NULL, '91230405000', 'hostel', 'temple', 'anand', 'po', 'pqr@gmail.com', 'P', 'M01'),
('sds12', '202cb962ac59075b964b07152d234b70', 'xcvc', 'Parul University', 'vcvcvb', '+165645', 'sfdfd', 'dfsdf', 'vbvcb', 'vbcvb', 'afs@gmail.com', 'P', 'M01');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `c_id` varchar(15) NOT NULL,
  `password` varchar(32) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `recruiter_name` varchar(30) NOT NULL,
  `website` varchar(50) DEFAULT NULL,
  `phone_no` varchar(15) NOT NULL,
  `location` varchar(30) NOT NULL,
  `landmark` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `approval_status` varchar(1) NOT NULL DEFAULT 'P' COMMENT 'P for panding,N for not approved,Y for apprroved',
  `m_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`c_id`, `password`, `company_name`, `recruiter_name`, `website`, `phone_no`, `location`, `landmark`, `city`, `email`, `approval_status`, `m_id`) VALUES
('CM01', '202cb962ac59075b964b07152d234b70', 'TCS', 'sqr', NULL, '9123041045', 'townhall', 'gcet', 'anand', 'sqr@gmail.com', 'P', 'M01'),
('scdcs', '202cb962ac59075b964b07152d234b70', 'xvcv', 'dfdsf', '', '+165645vxcv', 'cvxv', 'gfgf', 'gvc', 'aas@h.c', 'P', 'M01');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` varchar(15) NOT NULL,
  `age` int(2) NOT NULL,
  `post` varchar(15) NOT NULL,
  `vacancy` int(3) NOT NULL,
  `Field` varchar(15) NOT NULL,
  `SSC` decimal(4,2) UNSIGNED NOT NULL,
  `HSC` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Diploma_Result` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Diploma_Field` varchar(15) DEFAULT NULL,
  `Graduation_Result` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Graduation_Field` varchar(15) DEFAULT NULL,
  `Post_Graduation_Result` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Post_Graduation_Field` varchar(15) DEFAULT NULL,
  `PHD` varchar(1) DEFAULT NULL,
  `salary` int(10) NOT NULL,
  `skill` varchar(15) NOT NULL,
  `Date_time` datetime NOT NULL,
  `venue` varchar(60) NOT NULL,
  `exam_type` varchar(30) NOT NULL,
  `c_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `age`, `post`, `vacancy`, `Field`, `SSC`, `HSC`, `Diploma_Result`, `Diploma_Field`, `Graduation_Result`, `Graduation_Field`, `Post_Graduation_Result`, `Post_Graduation_Field`, `PHD`, `salary`, `skill`, `Date_time`, `venue`, `exam_type`, `c_id`) VALUES
('j01', 45, 'jdaf', 10, 'fwf', '85.00', '75.00', NULL, NULL, '8.50', NULL, '6.50', NULL, NULL, 679899, 'khdui', '2019-10-02 00:00:00', 'fr', 'safwe', '');

-- --------------------------------------------------------

--
-- Table structure for table `main_admin`
--

CREATE TABLE `main_admin` (
  `m_id` varchar(15) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone_no` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main_admin`
--

INSERT INTO `main_admin` (`m_id`, `password`, `email`, `name`, `phone_no`) VALUES
('001', '202cb962ac59075b964b07152d234b70', 'janvipandya1103@gmail.com', 'dadsgcb', '+918849473722'),
('M01', '123', 'abc@gmail.com', 'abc xyz', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `enroll_no` varchar(15) NOT NULL,
  `password` varchar(32) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `college_name` varchar(100) NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `approval_status` varchar(1) NOT NULL DEFAULT 'P' COMMENT 'P for panding,N for not approved,Y for apprroved',
  `DOB` date NOT NULL,
  `Gender` varchar(1) NOT NULL,
  `SSC` decimal(4,2) UNSIGNED DEFAULT NULL,
  `HSC` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Diploma_Result` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Diploma_Field` varchar(15) DEFAULT NULL,
  `Graduation_Result` decimal(4,2) UNSIGNED DEFAULT NULL,
  `Graduation_Field` varchar(15) DEFAULT NULL,
  `PostGraduation_Result` decimal(4,2) UNSIGNED DEFAULT NULL,
  `PostGraduation_Field` varchar(15) DEFAULT NULL,
  `PHD` varchar(1) DEFAULT NULL,
  `u_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`enroll_no`, `password`, `student_name`, `college_name`, `phone_no`, `email`, `approval_status`, `DOB`, `Gender`, `SSC`, `HSC`, `Diploma_Result`, `Diploma_Field`, `Graduation_Result`, `Graduation_Field`, `PostGraduation_Result`, `PostGraduation_Field`, `PHD`, `u_id`) VALUES
('123', '81dc9bdb52d04dc20036dbd8313ed055', 'abc', '', '9876', 'abc@gmail.com', 'P', '2019-12-11', 'f', '89.00', '23.00', '56.00', 'cp', '23.00', 'sshd', '56.00', 'jsa', 'n', 'C01'),
('16', '81dc9bdb52d04dc20036dbd8313ed055', 'afw', '', '9123040503', 'pqrz@gmail.com', 'P', '2002-09-02', 'f', '89.25', '75.00', '89.56', 'cp', '56.40', 'cp', '65.26', 'cp', NULL, 'C01'),
('176040307026', '81dc9bdb52d04dc20036dbd8313ed055', 'Janvi Pandya', 'BVM', '+918849473722', 'janvipandya1103@gmail.com', 'P', '2002-03-11', 'f', '85.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ab12'),
('1escxdv', '202cb962ac59075b964b07152d234b70', 'dadsgcb', 'BVM', '+919912345678', 'bvnskdbvc@gmail.com', 'P', '2020-01-08', 'f', '98.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ab12'),
('1q', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'qkd@gmail.com', 'P', '2020-01-05', 'f', '89.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('1qs', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'qkdk@gmail.com', 'P', '2020-01-05', 'm', '89.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('1qsa', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'skdk@gmail.com', 'P', '2020-01-05', 'm', '89.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('55gdfgre', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'abc1234rewew@gmail.com', 'P', '2020-01-05', 'f', '89.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('55gdfgrefdfg', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'abc1234rewewfgdfg@gmail.com', 'P', '2020-01-05', 'f', '89.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('acxzczx', '202cb962ac59075b964b07152d234b70', 'dads', 'bbit', '9012345678', 'skd@gmail.com', 'P', '2020-01-05', 'f', '98.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('cvcv123', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'abc1234@gmail.com', 'P', '2020-01-04', 'f', '90.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('saaxd111fdf', '202cb962ac59075b964b07152d234b70', 'dads', '', '9012345678', 'abc123412@gmail.com', 'P', '2020-01-04', 'f', '98.00', '90.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01'),
('vcb', '202cb962ac59075b964b07152d234b70', 'dadsgcb', 'BVM', '+189089', 'aas@h.c', 'P', '2020-01-08', 'f', '79.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ab12'),
('ythfbnb', '202cb962ac59075b964b07152d234b70', 'dads', 'BBIT', '9012345678', 'skdbvc@gmail.com', 'P', '2020-01-08', 'm', '98.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'C01');

-- --------------------------------------------------------

--
-- Table structure for table `stu_job`
--

CREATE TABLE `stu_job` (
  `job_id` varchar(15) NOT NULL,
  `enroll_no` varchar(15) NOT NULL,
  `job_status` varchar(1) NOT NULL,
  `application_status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stu_job`
--

INSERT INTO `stu_job` (`job_id`, `enroll_no`, `job_status`, `application_status`) VALUES
('j01', '16', 'p', 'p');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `u_id_3` (`u_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `m_id` (`m_id`),
  ADD KEY `u_id` (`u_id`),
  ADD KEY `u_id_2` (`u_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`c_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `m_id` (`m_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `main_admin`
--
ALTER TABLE `main_admin`
  ADD PRIMARY KEY (`m_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`enroll_no`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `stu_job`
--
ALTER TABLE `stu_job`
  ADD PRIMARY KEY (`job_id`,`enroll_no`),
  ADD KEY `job_id` (`job_id`,`enroll_no`),
  ADD KEY `enroll_no` (`enroll_no`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `college`
--
ALTER TABLE `college`
  ADD CONSTRAINT `college_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `main_admin` (`m_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `company_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `main_admin` (`m_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `college` (`u_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stu_job`
--
ALTER TABLE `stu_job`
  ADD CONSTRAINT `stu_job_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `stu_job_ibfk_2` FOREIGN KEY (`enroll_no`) REFERENCES `student` (`enroll_no`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
